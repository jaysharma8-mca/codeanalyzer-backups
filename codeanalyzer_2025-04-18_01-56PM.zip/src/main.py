print('Hello from Linux VM')
